﻿namespace dataTranferBurgett.Models
{
    public class Game
    {
        public string GameID { get; set; }
        public string Name { get; set; }
    }
}
