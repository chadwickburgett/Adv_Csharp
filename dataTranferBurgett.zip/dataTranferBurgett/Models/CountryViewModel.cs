﻿namespace dataTranferBurgett.Models
{
    public class CountryViewModel
    {
        public Country Country { get; set; }
        public string ActiveGame { get; set; }
        public string ActiveCat { get; set; }
        public string ActiveSport { get; set; }
    }
}
