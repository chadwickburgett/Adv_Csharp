﻿namespace dataTranferBurgett.Models
{
    public class Sport
    {
        public string SportID { get; set; }
        public string Name { get; set; }
    }
}
